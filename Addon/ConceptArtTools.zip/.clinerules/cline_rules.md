这是一个Blender 4.4 的插件项目， 配合vscode 的blender插件进行开发， 启用了auto load功能
文件头都要写 import bpy
util.py文件是通用的function
UI.py 是blender中的UI界面文件
忽略Addon目录， 下面是打包后的插件
使用context7 mcp调用blender的api文档