for plasticity-bridge group instance tool use https://github.com/LiuYangArt/PlasticityHelper


this addon is highly customize for my own workflow and have many experimental shit. 
